- Copy the contents of the Plugins folder (all 4 DLLs), which can be found in the same folder as this text file
= Paste the contents into the '...Subnautica\Subnautica_Data\Plugins' folder.
- Make sure your microphone is working, and enjoy!